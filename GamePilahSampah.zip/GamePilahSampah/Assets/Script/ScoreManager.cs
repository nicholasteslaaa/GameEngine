using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{   
    public Text txScore;
    private int score;
    public static ScoreManager instance;
    void Awake()
    {
        instance = this;
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        score = 0;
    }

    // Update is called once per frame
    void Update()
    {
        txScore.text = score.ToString();
        Debug.Log(score);
    }

    public void addScore(int param){
        score += param;
    }
    public void setScore(int param){
        score = param;
    }
}
