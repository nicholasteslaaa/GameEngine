using UnityEngine;

public class NewMonoBehaviourScript : MonoBehaviour
{
    public float jeda = 1f;
    float timer;
    public GameObject[] obyekSampah;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        timer = spawn(timer,jeda,obyekSampah);
    }

    // Update is called once per frame
    void Update()
    {
        timer = spawn(timer,jeda,obyekSampah);
    }

    float spawn(float timer, float jeda,GameObject[] obyekSampah){
        timer += Time.deltaTime;
        if (timer > jeda){
            int random = Random.Range(0, obyekSampah.Length);
            Instantiate(obyekSampah[random],transform.position,transform.rotation);
            return 0;
        }
        return timer;
    }
}
