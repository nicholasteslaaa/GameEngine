using UnityEngine;
using UnityEngine.SceneManagement;

public class Keluar : MonoBehaviour
{   
    float timer = 0;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    timer += Time.deltaTime;
    if (timer > 3*60){
        ScoreManager.instance.setScore(0);
        SceneManager.LoadScene("GameOver");
    }
     if (Input.GetKeyUp(KeyCode.Escape)){
        Debug.Log("escape");
        Application.Quit();
     }   
    }
}
