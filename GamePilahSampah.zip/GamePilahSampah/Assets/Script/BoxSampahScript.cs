using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class BoxSampahScript : MonoBehaviour
{   
    public AudioSource sound;
    public AudioClip right;
    public AudioClip wrong;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        sound = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnTriggerEnter2D(Collider2D coll)
    {   
        if(gameObject.name == "BoxNonOrganik"){
            if (coll.gameObject.tag == "nonorganik"){
                ScoreManager.instance.addScore(1);
                Destroy(coll.gameObject);
                sound.PlayOneShot(right);
            }
            else{
                sound.PlayOneShot(wrong);
            }
        }
        if(gameObject.name == "BoxOrganik"){
            if(coll.gameObject.tag == "organik"){
                ScoreManager.instance.addScore(1);
                Destroy(coll.gameObject);
                sound.PlayOneShot(right);
            }
            else{
                sound.PlayOneShot(wrong);
            }
        }            
    }
}
